/*
* Author: Sebastian Bierman-Lytle
* Last Updated: 2/16/2013
* Website: iioEngine.com
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:

* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.

* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.

* 3. This notice may not be removed or altered from any source distribution.
*/
var ioImage = Class.create(ioObj, {
	initialize: function($super, src, pos, y, callback) {
	$super(pos, y);
	if (src instanceof Image) {
		this.img = src;
		this.width=size||this.img.width||0;
		this.height=h||size||this.img.height||0;
	}
	else{
		this.img = new Image();
		this.img.src = src;
		this.img.onload = function(){
			this.width=this.img.width||0;
			this.height=this.img.height||0;
			callback();
		}.bind(this);
	}
  },
  draw: function($super, ctx){
  	$super(ctx);
	if (typeof(this.img) != 'undefined'){
		if (this.drawPartialPixels)
			ctx.drawImage(this.img, -this.width/2, -this.height/2, this.img.width, this.img.height);
		else ctx.drawImage(this.img, Math.round(-this.width/2), Math.round(-this.height/2), Math.round(this.img.width), Math.round(this.img.height));
	}
	ctx.restore();
  }
});