/*
* Author: Sebastian Bierman-Lytle
* Last Updated: 2/16/2013
* Website: iioEngine.com
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:

* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.

* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.

* 3. This notice may not be removed or altered from any source distribution.
*/
var ioApps=[];
var ioFPSApps=[];
isiPad = navigator.userAgent.match(/iPad/i) != null;

function ioStart(app, id, w, h){
	if (typeof(app)=='undefined') throw new Error("ioStart: No application script provided | Docs: ioController -> ioStart");
	ioApps[ioApps.length]=new ioApp(app, id, w, h);
}
function ioRequestFramerate(app){
	ioFPSApps[ioFPSApps.length]=app;
	if(ioFPSApps.length==1){
		//Callback method by Erik M�ller
		//https://gist.github.com/1579671
		var lastTime = 0;
	    var vendors = ['ms', 'moz', 'webkit', 'o'];
	    for(var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x){
	        window.requestAnimationFrame = window[vendors[x]+'RequestAnimationFrame'];
	        window.cancelAnimationFrame = 
	          window[vendors[x]+'CancelAnimationFrame'] || window[vendors[x]+'CancelRequestAnimationFrame'];
	    }
		window.requestAnimationFrame = function(callback, element) {
			var currTime = new Date().getTime();
	            var timeToCall = Math.max(0, 1000/app.fps - (currTime - lastTime));
				var dt = timeToCall/(1000/app.fps);
				dt=1;
	            var id = window.setTimeout(function() { callback(dt); },
	              1000/app.fps);//timeToCall);
				  if (timeToCall > 0) 
	            lastTime = currTime + timeToCall;
	            return id;
		}.bind(app);
	    if (!window.cancelAnimationFrame)
	        window.cancelAnimationFrame = function(id) {
	            clearTimeout(id);
        };		

		requestAnimationFrame(ioUpdateApps);
	}
}
function ioUpdateApps(dt){
	if (ioFPSApps[0].dBugger != undefined)
		ioFPSApps[0].dBugger.stats.begin();
	requestAnimationFrame( ioUpdateApps );
	for (var a=0; a<ioFPSApps.length; a++){
		ioFPSApps[a].step(dt)
		if (ioFPSApps[a].dBugger != undefined)
			ioFPSApps[a].dBugger.stats.end();
	}
}
function ioResizeApps(){
	//for (var a=0; a<ioApps.length; a++)
	//	ioApps[a].resize();
	lastTime = 0;
}