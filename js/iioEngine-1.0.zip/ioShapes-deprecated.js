/*
* Author: Sebastian Bierman-Lytle
* Last Updated: 2/16/2013
* Website: iioEngine.com
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:

* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.

* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.

* 3. This notice may not be removed or altered from any source distribution.
*/
var Physics = {
	update: function($super, dt){
		if (typeof(this.drawables) != 'undefined')
			for (var i=0;i<this.drawables.length;i++)
				if (typeof(this.drawables[i].update) != 'undefined')
					if(!this.drawables[i].update())
						return false;
		this.move(new ioVec(this.vel.x*dt, this.vel.y*dt));
		if (typeof(this.torque) != 'undefined') this.rotation+=this.torque;
		if (this.bounds != null && ((this.bounds.top != null && this.pos.y < this.bounds.top) || (this.bounds.right != null && this.pos.x > this.bounds.right) || (this.bounds.bottom != null && this.pos.y > this.bounds.bottom) || (this.bounds.left != null && this.pos.x < this.bounds.left)))
			return false;
		return true;
	},
	draw: function($super, ctx){
		if (typeof(this.drawables) != 'undefined'){
			ctx.save();
			ctx.translate(this.pos.x, this.pos.y);
			if (typeof(this.rotation) != 'undefined') 
				ctx.rotate(this.rotation);
			for (var i=0; i<this.drawables.length; i++)
				this.drawables[i].draw(ctx, this.pos);
			ctx.restore();
		}
		if (this.drawBox){
			//draw outside border
			ctx.strokeStyle = '#fff';
			ctx.strokeRect(this.left(), this.top(), this.width, this.height);
		}
		$super(ctx);
	},
	setVel: function(x,y){
		this.vel.x = x;
		this.vel.y = y;
		return this;
	  },
  	setTorque: function(t){
		this.torque = t;
		if (typeof(this.rotation)=='undefined') 
			this.rotation = 0;
		return this;
  	},
  	setBounds: function(top, right, bottom, left){
		this.bounds = new Object();
		this.bounds.top = top;
		this.bounds.right = right;
		this.bounds.bottom = bottom;
		this.bounds.left = left;
		return this;
  	}
}
var ioShape = Class.create(ioObj, {
	initialize: function($super, pos, y, vel, velY){
		$super(pos, y);
		if (typeof(velY) == 'undefined')
			this.vel = vel || new ioVec();
		else this.vel = new ioVec(vel,velY);
	},
});