/*
* Author: Sebastian Bierman-Lytle
* Last Updated: 2/28/2013
* Website: iioEngine.com
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:

* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.

* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.

* 3. This notice may not be removed or altered from any source distribution.
*/
function SpaceShooter(iio){
    var ioVec = iio.ioVec,
    ioObj = iio.ioObj,
    ioX = iio.ioX,
    ioLine = iio.ioLine,
    ioRect = iio.ioRect,
    ioCircle = iio.ioCircle,
    ioText = iio.ioText,
    ioGrid = iio.ioGrid;

	var io;
    var player;
    var playerHSpeed = 9;
    var playerVSpeed = 8;
    var playerMove = [0,0,0,0,0];
    var spaceDown = false;
    var backgroundSpeed = 18;
    var asteroidHealth = 3;

    var imgPath = 'img-SpaceShooter/';

    var backgroundSrcs = [imgPath+'Background/starBig.png', 
                        imgPath+'Background/starSmall.png', 
                        imgPath+'Background/speedLine.png', 
                        imgPath+'Background/nebula.png'];

    var asteroidSrcs = [imgPath+'meteorBig.png', 
                        imgPath+'meteorSmall.png'];

	this.init = function(appManager){
		io = appManager;
    	io.setBGColor('#5e3f6b');
        io.createGroup('asteroids', 0);
        io.createGroup('stars', -30);
        io.createGroup('nebulas', -20);
        io.createGroup('player', 10);
        io.createGroup('player bullets', 10);
        io.createGroup('lasor flashes', 15);

        //create player
        var srcs = [imgPath+'playerLeft.png',
                    imgPath+'player.png',
                    imgPath+'playerRight.png'];

        player = io.addToGroup('player', new ioRect(io.canvas.center.x, io.canvas.height-100));
        player.createWithAnim(srcs, 1);

        setCollisionCallbacks();
    	io.setFramerate(60);
	}
    
    var shootTimer = 20;
    var shootCount = 0;
    this.update = function(dt){
        updateBackground();
        updatePlayer();
        if (spaceDown && shootCount < 0){
            createBullet(player.left()+10, player.pos.y);
            createBullet(player.right()-8, player.pos.y);
            shootCount = shootTimer;
        } 
        if (spaceDown) shootCount--;
        else shootCount-=4;
    }

    function setCollisionCallbacks(){
        io.setCollisionCallback('player bullets', 'asteroids', function(bullet, asteroid){
            io.addToGroup('lasor flashes', new ioRect((bullet.pos.x+asteroid.pos.x)/2, (bullet.pos.y+asteroid.pos.y)/2)).createWithImage(imgPath+'laserRedShot.png').setVel(asteroid.vel.x, asteroid.vel.y).shrink(.1);
            io.destroyInGroup(bullet, 'player bullets');
            if (typeof(asteroid.health) != 'undefined'){
                asteroid.health--;
                if (asteroid.health < 0){
                    var numFragments = iio.getRandomInt(3,6);
                    for (var i=0; i<numFragments; i++)
                        io.addToGroup('asteroids', new ioRect(asteroid.pos.x+iio.getRandomInt(-20,20), asteroid.pos.y+iio.getRandomInt(-20,20))).createWithImage(asteroidSrcs[1]).setVel(iio.getRandomNum(-2,2), iio.getRandomNum(10,14)).setBounds(null, null, io.canvas.height+40, null).setTorque(iio.getRandomNum(-.1,.1))
                    io.destroyInGroup(asteroid, 'asteroids');
                }
            } else {
                io.destroyInGroup(asteroid, 'asteroids');
                //score+=10;
                //scoreText.setText('Score: '+score);
            }
        });
    }

    function createBullet(x,y){
        io.addToGroup('player bullets', new ioRect(x,y), 10).createWithImage(imgPath+'laserRed.png').setBounds(-40,null,null,null).setVel(0,-16);
    }

    var bgCreatorDelay = 80;
    var bgCount = 0;
    function updateBackground(){
        if (bgCount < 1){
            runBgCreator(-io.canvas.height*2, 0);
            asteroidDensity = 3;
            for (var i=0; i<asteroidDensity; i++){
                createLargeAsteroids();
                createSmallAsteroids();
            }
            bgCount = bgCreatorDelay;
        } else bgCount--;
    }

    function runBgCreator(yMin, yMax){
        for (var i=0; i<4; i++)
            for (var j=i*io.canvas.width/4; j< (i+1)*io.canvas.width/4; j++)
                if (iio.getRandomNum(0,10) < .2)
                    io.addObj(new ioRect(j, iio.getRandomInt(yMin, yMax)), -20).createWithImage(backgroundSrcs[3]).setVel(0,backgroundSpeed).setBounds(null,null,io.canvas.height+100,null);
                else if (iio.getRandomNum(0,10) < .4)
                    io.addObj(new ioRect(j, iio.getRandomInt(yMin, yMax)), -30).createWithImage(backgroundSrcs[iio.getRandomInt(0,1)]).setVel(0,Math.round(backgroundSpeed/2)).setBounds(null,null,io.canvas.height+20, null);
    }

    function createLargeAsteroids(){
        var asteroid;
        if (iio.getRandomNum(0, 10) < 8){
            asteroid = io.addToGroup('asteroids', new ioRect(iio.getRandomInt(30,io.canvas.width-30), iio.getRandomInt(-800,-50))).createWithImage(asteroidSrcs[0]).setVel(iio.getRandomInt(-2,2), iio.getRandomInt(10,14)).setBounds(null, null, io.canvas.height+40, null).setTorque(iio.getRandomNum(-.1,.1));
            asteroid.health = asteroidHealth;
        }
    }
    function createSmallAsteroids(){
        if (iio.getRandomNum(0, 10) < 8)
            io.addToGroup('asteroids', new ioRect(iio.getRandomInt(30,io.canvas.width-30), iio.getRandomInt(-800,-50))).setBounds(null, null, io.canvas.height+40, null).createWithImage(asteroidSrcs[1]).setVel(iio.getRandomInt(-2,2), iio.getRandomInt(10,14)).setTorque(iio.getRandomNum(-.1,.1));
    }

    function updatePlayer(){
        if (playerMove[1] > 0){
            if (player.pos.x > Math.round(player.width/2+1)){
                player.translate(-playerHSpeed,0); 
                player.animIndex=0;
            } else player.animIndex=1;
        }
        if (playerMove[2] && player.pos.y > Math.round(player.height/2)) 
            player.translate(0,-playerVSpeed);
        if (playerMove[3] > 0 && player.pos.y < io.canvas.height-Math.round(player.height/2)){
            player.translate(0,playerVSpeed);
        }
        if (playerMove[4] > 0){
            if (player.pos.x < io.canvas.width-Math.round(player.width/2)){
                player.translate(playerHSpeed,0); 
                player.animIndex=2;
            } else player.animIndex=1;
        }
        if (playerMove[1] > 0 && playerMove[4] > 0)
            player.animIndex=1;
    }
    
    this.keyDown = function(event){
        if (iio.keyCodeIs('left arrow', event) || iio.keyCodeIs('a', event))
            playerMove[1] = 1;
        if (iio.keyCodeIs('up arrow', event) || iio.keyCodeIs('w', event))
            playerMove[2] = 1;
        if (iio.keyCodeIs('right arrow', event) || iio.keyCodeIs('d', event))
            playerMove[4] = 1;
        if (iio.keyCodeIs('down arrow', event) || iio.keyCodeIs('s', event))
            playerMove[3] = 1;
        if (iio.keyCodeIs('space', event)){
            spaceDown = true;
        }
    }

    this.keyUp = function(event){
        if (iio.keyCodeIs('left arrow', event) || iio.keyCodeIs('a', event)){
            player.animIndex=1;
            playerMove[1] = 0;
        }
        if(iio.keyCodeIs('up arrow', event) || iio.keyCodeIs('w', event))
            playerMove[2] = 0;
        if (iio.keyCodeIs('right arrow', event) || iio.keyCodeIs('d', event)){
            player.animIndex=1;
            playerMove[4] = 0;
        }
        if (iio.keyCodeIs('down arrow', event) || iio.keyCodeIs('s', event))
            playerMove[3] = 0;
        if (iio.keyCodeIs('space', event))
            spaceDown = false;
    }
}

