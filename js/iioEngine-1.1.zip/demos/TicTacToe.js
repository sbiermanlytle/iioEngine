/*
* Author: Sebastian Bierman-Lytle
* Last Updated: 2/28/2013
* Website: iioEngine.com
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:

* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.

* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.

* 3. This notice may not be removed or altered from any source distribution.
*/
function TicTacToe(iio){
	var ioVec = iio.ioVec,
    	ioObj = iio.ioObj,
    	ioX = iio.ioX,
    	ioLine = iio.ioLine,
    	ioRect = iio.ioRect,
    	ioBox = iio.ioBox,
    	ioCircle = iio.ioCircle,
    	ioText = iio.ioText,
    	ioGrid = iio.ioGrid;

	var app, grid;
	var xTurn = true;
	this.init = function(appManager){
		app = appManager;
		grid = app.addObj(new ioGrid(15, 15, 3, 3, 140)).draw(app.context);
	}
	this.inputDown = function(event){
		var pos = app.getEventPosition(event);
		var cI = grid.getIndiciesOf(pos);
		if (typeof(grid.cells[cI.x][cI.y].taken) == 'undefined'){
			var p = grid.getCellCenter(cI.x, cI.y);
			if (xTurn) app.addObj(new ioX(p.x, p.y, 100)).draw(app.context);
			else app.addObj(new ioCircle(p.x, p.y, 50, false)).draw(app.context);
			grid.cells[cI.x][cI.y].taken = true;
			xTurn=!xTurn;
		}
	}
}