/*
* Author: Sebastian Bierman-Lytle
* Last Updated: 2/28/2013
* Website: iioEngine.com
*
* This software is provided 'as-is', without any express or implied
* warranty.  In no event will the authors be held liable for any damages
* arising from the use of this software.
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:

* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software. If you use this software
* in a product, an acknowledgment in the product documentation would be
* appreciated but is not required.

* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.

* 3. This notice may not be removed or altered from any source distribution.
*/

function B2D(iio) {

   var   b2Vec2 = Box2D.Common.Math.b2Vec2
      ,  b2AABB = Box2D.Collision.b2AABB
   	,	b2BodyDef = Box2D.Dynamics.b2BodyDef
   	,	b2Body = Box2D.Dynamics.b2Body
   	,	b2FixtureDef = Box2D.Dynamics.b2FixtureDef
   	,	b2Fixture = Box2D.Dynamics.b2Fixture
   	,	b2World = Box2D.Dynamics.b2World
   	,	b2MassData = Box2D.Collision.Shapes.b2MassData
   	,	b2PolygonShape = Box2D.Collision.Shapes.b2PolygonShape
   	,	b2CircleShape = Box2D.Collision.Shapes.b2CircleShape
   	,	b2DebugDraw = Box2D.Dynamics.b2DebugDraw
      ,  b2MouseJointDef =  Box2D.Dynamics.Joints.b2MouseJointDef
      ;

   var world = new b2World(
         new b2Vec2(0, 10)    //gravity
      ,  true                 //allow sleep
   );
   
   var fixDef = new b2FixtureDef;
   fixDef.density = 1.0;
   fixDef.friction = 0.5;
   fixDef.restitution = 0.2;
   
   var bodyDef = new b2BodyDef;

   var app;
   var mouseX, mouseY, mousePVec, isMouseDown, selectedBody, mouseJoint;
   var canvasPosition;

   this.init = function(appManager){
      app = appManager;
      app.b2World=world;

      canvasPosition = iio.getElementPosition(app.canvas);

      var f,width,height;
      //create ground
      bodyDef.type = b2Body.b2_staticBody;
      fixDef.shape = new b2PolygonShape;
      width = 20;
      height = 2;
      var scale = 60;
      fixDef.shape.SetAsBox(20, 2);
      bodyDef.position.Set(15, 14);
      f=app.addObj(world.CreateBody(bodyDef)).CreateFixture(fixDef);
      f.m_shape.addImage('img-B2DPlatformer/ground_dirt.png');
      f.m_shape.width = width*scale;
      f.m_shape.height = height*scale;

      bodyDef.position.Set(15, -1.8);
       f=app.addObj(world.CreateBody(bodyDef)).CreateFixture(fixDef);
      f.m_shape.addImage('img-B2DPlatformer/ground_dirt.png');
      f.m_shape.width = width*scale;
      f.m_shape.height = height*scale;

      fixDef.shape.SetAsBox(2, 14);
      width = 2;
      height = 14;
      bodyDef.position.Set(-1.8, 13);
      f=app.addObj(world.CreateBody(bodyDef)).CreateFixture(fixDef);
      f.m_shape.addImage('img-B2DPlatformer/ground_dirt.png');
      f.m_shape.width = width*scale;
      f.m_shape.height = height*scale;

      bodyDef.position.Set(33.1, 13);
      f=app.addObj(world.CreateBody(bodyDef)).CreateFixture(fixDef);
      f.m_shape.addImage('img-B2DPlatformer/ground_dirt.png');
      f.m_shape.width = width*scale;
      f.m_shape.height = height*scale;
      
      
      //create some objects
      bodyDef.type = b2Body.b2_dynamicBody;
      for(var i = 0; i < 20; ++i) {
         width = Math.random() + 0.1 //half width
         height = Math.random() + 0.1 //half height
         if(Math.random() > 0.5) {
            fixDef.shape = new b2PolygonShape;
            fixDef.shape.SetAsBox(width, height);
         } else {
            fixDef.shape = new b2CircleShape(width);
         }
         bodyDef.position.x = Math.random() * 30;
         bodyDef.position.y = Math.random() * 10;
         f=app.addObj(world.CreateBody(bodyDef)).CreateFixture(fixDef);
         if (typeof f.m_shape.addImage!='undefined'){
            if (f.m_shape instanceof b2CircleShape){
               f.m_shape.addImage('img-B2DPlatformer/coin_gold.png');
               f.m_shape.width = width*60;
               f.m_shape.height = width*60;
            }
            else {
               f.m_shape.addImage('img-B2DPlatformer/block.png');
               f.m_shape.width = width*60;
               f.m_shape.height = height*60;
            }
         }
      }
      
      //setup debug draw
      /*
      var debugDraw = new b2DebugDraw();
      debugDraw.SetSprite(document.getElementById("b2d-demo").getContext("2d"));
      debugDraw.SetDrawScale(30.0);
      debugDraw.SetFillAlpha(0.5);
      debugDraw.SetLineThickness(1.0);
      debugDraw.SetFlags(b2DebugDraw.e_shapeBit | b2DebugDraw.e_jointBit);
      world.SetDebugDraw(debugDraw);
      */
      
      app.setFramerate(60);
   }

   this.update = function() {
      if(isMouseDown && (!mouseJoint)) {
         var body = getBodyAtMouse();
         if(body) {
            var md = new b2MouseJointDef();
            md.bodyA = world.GetGroundBody();
            md.bodyB = body;
            md.target.Set(mouseX, mouseY);
            md.collideConnected = true;
            md.maxForce = 300.0 * body.GetMass();
            mouseJoint = world.CreateJoint(md);
            body.SetAwake(true);
         }
      }
      if(mouseJoint) {
         if(isMouseDown) {
            mouseJoint.SetTarget(new b2Vec2(mouseX, mouseY));
         } else {
            world.DestroyJoint(mouseJoint);
            mouseJoint = null;
         }
      }
      world.DrawDebugData();
      world.ClearForces();
   };
   
   this.mouseDown = function(e){
       isMouseDown = true;
       this.mouseMove(e);
   }
   this.mouseUp = function(e){
      isMouseDown = false;
      mouseX = undefined;
      mouseY = undefined;
   }
   this.mouseMove = function(e){
      mouseX = (app.getEventPosition(e).x) / 30;
      mouseY = (app.getEventPosition(e).y) / 30;
   }
   
   function getBodyAtMouse() {
      mousePVec = new b2Vec2(mouseX, mouseY);
      var aabb = new b2AABB();
      aabb.lowerBound.Set(mouseX - 0.001, mouseY - 0.001);
      aabb.upperBound.Set(mouseX + 0.001, mouseY + 0.001);
      
      // Query the world for overlapping shapes.

      selectedBody = null;
      world.QueryAABB(getBodyCB, aabb);
      return selectedBody;
   }
   function getBodyCB(fixture) {
      if(fixture.GetBody().GetType() != b2Body.b2_staticBody) {
         if(fixture.GetShape().TestPoint(fixture.GetBody().GetTransform(), mousePVec)) {
            selectedBody = fixture.GetBody();
            return false;
         }
      }
      return true;
   }
}