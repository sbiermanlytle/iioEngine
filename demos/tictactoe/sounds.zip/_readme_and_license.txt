Sound pack downloaded from Freesound.org
----------------------------------------

This pack of sounds contains sounds by soundnimja ( http://www.freesound.org/people/soundnimja/  )
You can find this pack online at: http://www.freesound.org/people/soundnimja/packs/10865/


License details
---------------

Sampling+: http://creativecommons.org/licenses/sampling+/1.0/
Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/
Attribution: http://creativecommons.org/licenses/by/3.0/
Attribution Noncommercial: http://creativecommons.org/licenses/by-nc/3.0/


Sounds in this pack
-------------------

  * 173328__soundnimja__blip-1.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173328/
    * license: Attribution
  * 173327__soundnimja__blip-2.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173327/
    * license: Attribution
  * 173326__soundnimja__jump-1.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173326/
    * license: Attribution
  * 173325__soundnimja__static.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173325/
    * license: Attribution
  * 173324__soundnimja__coin-3.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173324/
    * license: Creative Commons 0
  * 173323__soundnimja__coin-4.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173323/
    * license: Creative Commons 0
  * 173322__soundnimja__coin-5.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173322/
    * license: Creative Commons 0
  * 173321__soundnimja__coin-1.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173321/
    * license: Creative Commons 0
  * 173320__soundnimja__coin-2.wav
    * url: http://www.freesound.org/people/soundnimja/sounds/173320/
    * license: Creative Commons 0

